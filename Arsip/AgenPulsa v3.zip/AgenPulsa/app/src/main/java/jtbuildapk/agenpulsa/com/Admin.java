package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.os.*;

public class Admin extends Activity
{
	@Override
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.adm_me);
		
	
	}
	
	
}

package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.telephony.gsm.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class Char extends Activity
{
	SessionManager session;
	EditText code;
	TextView stat;
	@Override
	protected void onCreate(Bundle savedInstanceState)
    {
		
		
		
		
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.txt_edit_c_har);
		
		
		session = new SessionManager(getApplicationContext());

		// get user data from session
		final HashMap<String, String> user = session.getUserDetails();

		// name
		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		final String cs = user.get(SessionManager.KEY_CS);
		
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		final String iname = extras.getString("name");
		
		stat = (TextView)findViewById(R.id.text_entity_cek);
		stat.setText(iname);
		
		code = (EditText)findViewById(R.id.t_c_har);
		
		}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		
		
		HashMap<String, String> user = session.getUserDetails();

		String cs = user.get(SessionManager.KEY_CS);

		if(cs.equals("0722")){getMenuInflater().inflate(R.menu.send, menu);
		}else{
			if(cs.equals("6289633300091")){getMenuInflater().inflate(R.menu.send, menu);
			}else{
				if(cs.equals("6281543336365")){

					getMenuInflater().inflate(R.menu.send, menu);

				}else{
					if(cs.equals("089633300091")){getMenuInflater().inflate(R.menu.send, menu);
					}else{
						if(cs.equals("081543336365")){

							getMenuInflater().inflate(R.menu.send, menu);

						}else{
							getMenuInflater().inflate(R.menu.send1, menu);


						}}}}}
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{ switch(item.getItemId()){
		
			case(R.id.send_bar1):
				kirim1();

		}
		switch(item.getItemId()){
			case(R.id.sendwa):
				kirimwa();
				break;
		}




		switch(item.getItemId()){
			case(R.id.send_bar):
				kirim();


		}return false;
	}

	private void kirimwa()
	{
		final HashMap<String, String> user = session.getUserDetails();

		// name
		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		final String cs = user.get(SessionManager.KEY_CS);
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		final String istatus = extras.getString("status");
		
		
		String codes = code.getText().toString();
		String sms = istatus+"."+codes;

		if(cs.equals("081543336365")){

			String smsNumber = "6281543336365" ; //without '+'
			try {
				Intent sendIntent = new Intent("android.intent.action.MAIN");
				//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.setType("text/plain");
				sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
				sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
				sendIntent.setPackage("com.whatsapp");
				startActivity(sendIntent);
			} catch(Exception e) {
				Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
			}
		}else{


			if(cs.equals("089633300091")){

				String smsNumber = "6289633300091" ; //without '+'
				try {
					Intent sendIntent = new Intent("android.intent.action.MAIN");
					//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
					sendIntent.setAction(Intent.ACTION_SEND);
					sendIntent.setType("text/plain");
					sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
					sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
					sendIntent.setPackage("com.whatsapp");
					startActivity(sendIntent);
				} catch(Exception e) {
					Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
				}
			}else{

				if(cs.equals(cs)){

					String smsNumber = cs; //without '+'
					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
						Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
					}


				}
			}}}
	
		

	


	private void kirim1()


	{
		
		final HashMap<String, String> user = session.getUserDetails();

		
		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		final String cs = user.get(SessionManager.KEY_CS);
		
		

		
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		final String istatus = extras.getString("status");
		
		
		
		
		String codes = code.getText().toString();

		Uri uri = Uri.parse("smsto:" + cs);
		String sms = istatus+"."+codes;
		Intent smsSIntent = new Intent(Intent.ACTION_SENDTO, uri);

		
		smsSIntent.putExtra("sms_body", sms);
		try
		{
			startActivity(smsSIntent);
		} catch (Exception ex) {
			Toast.makeText(Char.this, "Pengiriman SMS Gagal...",
						   Toast.LENGTH_LONG).show();
			ex.printStackTrace();
		}


		// TODO: Implement this method
	}




		
	private void kirim()
	{
		final HashMap<String, String> user = session.getUserDetails();


		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		final String cs = user.get(SessionManager.KEY_CS);
		
		
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		final String istatus = extras.getString("status");
		
		String codes = code.getText().toString();
		String sms = istatus+"."+codes;
		
		try {

			SmsManager smsManager = SmsManager.getDefault();

			smsManager.sendTextMessage(cs, null, sms , null, null);
			Toast.makeText(getApplicationContext(), "Terkirim!",
						   Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(),
						   "Gagal!. Terjadi masalah Saat Pengiriman",
						   Toast.LENGTH_LONG).show();
			e.printStackTrace();


		}}}
	

package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.telephony.gsm.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.*;
import java.io.*;

public class Im_5k extends Activity
{
	SessionManager session;
	AlertDialogManager alert = new AlertDialogManager();
	
	TextView code,pin,direct;
	EditText cod,pi,dir;
	
	
	Button Kirim,Kirim1;
	TextView notoken;
	
	
	
@Override
	public void onCreate(Bundle savedInstanceState)
	{
		
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.im_5k);
		
	Bundle extras = getIntent().getExtras();
	if (extras == null) {
		return;
	}
	
	// assign the values to string-arguments
	final String icode = extras.getString("code");
	final String itoken = extras.getString("token");
	cod = (EditText)findViewById(R.id.code_i5k);
	cod.setText(icode);
	
	
	
	
	notoken = (TextView)findViewById(R.id.nocon_token);
	session = new SessionManager(getApplicationContext());
	
	// get user data from session
	final HashMap<String, String> user = session.getUserDetails();

	// name
	final String name = user.get(SessionManager.KEY_NAME);
	final String pin = user.get(SessionManager.KEY_PIN);
	
	
	
	direct = (TextView)findViewById(R.id.sender);
	
	dir = (EditText)findViewById(R.id.direct_i5k);
	pi = (EditText)findViewById(R.id.pin_i5k);
	
	//String
	
	
	//SetText
	direct.setText(Html.fromHtml(name));
	pi.setText(Html.fromHtml(pin));
	
	//Button
	
	Kirim = (Button)findViewById(R.id.kirim_i5k);

	
	Kirim = (Button)findViewById(R.id.kirim_i5k);
	
	Kirim.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
				
				String Dirs = dir.getText().toString();
				String sms = icode+"."+Dirs+"."+pin;
				String cs = user.get(SessionManager.KEY_CS);

				if(cs.equals("0722")){
					kirimwa();
				}else{
					if(cs.equals("6289633300091")){kirimwa();
					}else{
						if(cs.equals("6281543336365")){

							kirimwa();

						}else{
							if(cs.equals("089633300091")){
								kirimwa();
							}else{
								if(cs.equals("081543336365")){

									kirimwa();

								}else{
									kirim();


								}}}}}

				
			
					
				
				}});
				
				Kirim1 = (Button)findViewById(R.id.kirim_i5ki);
				Kirim1.setOnClickListener(new OnClickListener(){
					
					@Override
					public void onClick(View v){
						String cs = user.get(SessionManager.KEY_CS);
						
						if(cs.equals("0722")){
							kirimwa();
						}else{
							if(cs.equals("6289633300091")){kirimwa();
							}else{
								if(cs.equals("6281543336365")){

									kirimwa();

								}else{
									if(cs.equals("089633300091")){
										kirimwa();
									}else{
										if(cs.equals("081543336365")){

											kirimwa();

										}else{
											sendSmsBySIntent();


										}}}}}

						
						
						
					}

					
						
					private void sendSmsBySIntent() {
						String cs = user.get(SessionManager.KEY_CS);
						String pin = user.get(SessionManager.KEY_PIN);
						
						String Dirs = dir.getText().toString();
						
						String sms = icode+"."+Dirs+"."+pin;
						// menambahkan phone number ke URI data
						Uri uri = Uri.parse("smsto:" + cs);
						// membuat intent baru dengan ACTION_SENDTO
						Intent smsSIntent = new Intent(Intent.ACTION_SENDTO, uri);
						// menambahkan isi SMS pada field sms_body
						
						smsSIntent.putExtra("sms_body", sms);
						
						
						
									
						
						try
{
							startActivity(smsSIntent);
						} catch (Exception ex) {
							Toast.makeText(Im_5k.this, "Pengiriman SMS Gagal...",
										   Toast.LENGTH_LONG).show();
							ex.printStackTrace();
						}
					}
						// TODO: Implement this method
				
					
					});
					
	String cs = user.get(SessionManager.KEY_CS);
	
				
			
					
				}
			
@Override
public boolean onCreateOptionsMenu(Menu menu) {
	HashMap<String, String> user = session.getUserDetails();
	
	String cs = user.get(SessionManager.KEY_CS);

	if(cs.equals("0722")){getMenuInflater().inflate(R.menu.send, menu);
	}else{
		if(cs.equals("6289633300091")){getMenuInflater().inflate(R.menu.send, menu);
		}else{
			if(cs.equals("6281543336365")){

				getMenuInflater().inflate(R.menu.send, menu);

			}else{
				if(cs.equals("089633300091")){getMenuInflater().inflate(R.menu.send, menu);
				}else{
					if(cs.equals("081543336365")){

						getMenuInflater().inflate(R.menu.send, menu);

					}else{
						getMenuInflater().inflate(R.menu.send1, menu);
						
	
	}}}
}}
	return true;
}

	
	@Override
	
	public boolean onOptionsItemSelected(MenuItem item)
	{ switch(item.getItemId()){
		
		case(R.id.send_bar1):
				kirim1();
			
				}
		switch(item.getItemId()){
			case(R.id.sendwa):
				kirimwa();
				break;
				}
			

		
				
switch(item.getItemId()){
		case(R.id.send_bar):
		kirim();
		
		
		}return false;
	}

	private void kirimwa()
	{
		
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		String icode = extras.getString("code");


		String Dirs = dir.getText().toString();

		final HashMap<String, String> user = session.getUserDetails();
		String pin = user.get(SessionManager.KEY_PIN);
		String cs = user.get(SessionManager.KEY_CS);

		String sms = icode+"."+Dirs+"."+pin;
		
		if(cs.equals("081543336365")){

			String smsNumber = "6281543336365" ; //without '+'
			try {
				Intent sendIntent = new Intent("android.intent.action.MAIN");
				//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
				sendIntent.setAction(Intent.ACTION_SEND);
				sendIntent.setType("text/plain");
				sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
				sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
				sendIntent.setPackage("com.whatsapp");
				startActivity(sendIntent);
			} catch(Exception e) {
				Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
			}
		}else{


			if(cs.equals("089633300091")){

				String smsNumber = "6289633300091" ; //without '+'
				try {
					Intent sendIntent = new Intent("android.intent.action.MAIN");
					//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
					sendIntent.setAction(Intent.ACTION_SEND);
					sendIntent.setType("text/plain");
					sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
					sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
					sendIntent.setPackage("com.whatsapp");
					startActivity(sendIntent);
				} catch(Exception e) {
					Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
				}
			}else{

				if(cs.equals(cs)){

					String smsNumber = cs; //without '+'
					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
						Toast.makeText(this, "Error/n" + e.toString(), Toast.LENGTH_SHORT).show();
					}


				}
			

	}}}
	
		
		
	
	
	
	private void kirim1()
	

	{
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		String icode = extras.getString("code");
		

		String Dirs = dir.getText().toString();

		final HashMap<String, String> user = session.getUserDetails();
		String pin = user.get(SessionManager.KEY_PIN);
		String cs = user.get(SessionManager.KEY_CS);
		
		String sms = icode+"."+Dirs+"."+pin;
		
		Uri uri = Uri.parse("smsto:" + cs);

		Intent smsSIntent = new Intent(Intent.ACTION_SENDTO, uri);
		
		
		smsSIntent.putExtra("sms_body", sms);
		try
		{
			startActivity(smsSIntent);
		} catch (Exception ex) {
			Toast.makeText(Im_5k.this, "Pengiriman SMS Gagal...",
						   Toast.LENGTH_LONG).show();
			ex.printStackTrace();
		}
		
		
		// TODO: Implement this method
	}


			
	
	

	private void kirim()
	{
		Bundle extras = getIntent().getExtras();
		if (extras == null) {
			return;
		}

		// assign the values to string-arguments
		String icode = extras.getString("code");


		String Dirs = dir.getText().toString();

		final HashMap<String, String> user = session.getUserDetails();
		String pin = user.get(SessionManager.KEY_PIN);
		String cs = user.get(SessionManager.KEY_CS);

		String sms = icode+"."+Dirs+"."+pin;
		
		
		try {
			
			SmsManager smsManager = SmsManager.getDefault();
			
			smsManager.sendTextMessage(cs, null, sms , null, null);
			Toast.makeText(getApplicationContext(), "Terkirim!",
						   Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			Toast.makeText(getApplicationContext(),
						   "Gagal!. Terjadi masalah Saat Pengiriman",
						   Toast.LENGTH_LONG).show();
			e.printStackTrace();
		
		
	}
	
	
	}}
		
	
		
	
				
				

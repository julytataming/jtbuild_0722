package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.os.*;
import android.widget.*;

public class Tentang extends Activity
{
	Jtataming Jcode = new Jtataming();
	string Jtext = new string();
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{ super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		
        Toast.makeText(getApplicationContext(), Jcode.JtDe(Jtext.amb), Toast.LENGTH_LONG).show();
		
		

	}


	}

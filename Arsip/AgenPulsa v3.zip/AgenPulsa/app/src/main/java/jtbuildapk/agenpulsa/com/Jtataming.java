package jtbuildapk.agenpulsa.com;

import android.content.*;
import android.view.*;
import android.widget.*;

public class Jtataming
{
	
	public void JulBinerDec(TextView b, String c)
	{
		b.setText(JtDe(c.replace("a7c","1").replace("b5d","0")));


	}
	
	public void JulBinerDec1(TextView b, String c)
	{
		b.setHint(JtDe(c.replace("a7c","1").replace("b5d","0")));


	}
	static final String JtDe(String input) {
		try {
			String julytataming = "";
			int jeol = input.length() / 8;
			for (int i = 0; i < jeol; i++) {
				julytataming = julytataming + ((char) Integer.parseInt(input.substring(i * 8, (i + 1) * 8), 2));
			}
			return julytataming;
		} catch (NumberFormatException e) {

			return "";


		}}







	static final String jultext(String input) {
		String julyanus = "";
		for (int i = 0; i < input.length(); i++) {
			String add = Integer.toBinaryString(input.charAt(i));
			while (add.length() != 8) {
				add = "0"+ add;
			}
			julyanus = julyanus + add + "";

		}

		return julyanus;



	}





	public static final String JtDeEdtTxt(String txt)
	{

		JtDe((txt).replace("a", "1").replace("b","0"));



		return txt;
	}

	public static final void JtTextDeFromRep(TextView b, String c){

		b.setText(JtDe(c.replace("a","1").replace("b","0").replace("c","1").replace("d","0").replace("y","1").replace("z","0")));




	}
	public static final void JtTextJeolRealEn(TextView b, String c){

		b.setText(c.replace("a","jt").replace("b","07").replace("c","2F").replace("d","3f").replace("e","f3").replace("f","F4")
				  .replace("g","5g").replace("h","6G").replace("i","g7").replace("j","G8").replace("k","9h").replace("l","0H")
				  .replace("m","h1").replace("n","h2").replace("o","3i").replace("p","4i").replace("q","i5").replace("r","i6")
				  .replace("s","7j").replace("t","8J").replace("u","J9").replace("v","j0").replace("w","ik").replace("x","2k")
				  .replace("y","k3").replace("z","K4").replace(" ","00")


				  .replace("A","l").replace("B","k").replace("C","j").replace("D","o").replace("E","N").replace("F","m")
				  .replace("G","r").replace("H","Q").replace("I","P").replace("J","u").replace("K","T").replace("L","s")
				  .replace("M","x").replace("N","W").replace("O","v").replace("P","a").replace("Q","Z").replace("R","Y")
				  .replace("S","B").replace("T","c").replace("U","D").replace("V","g").replace("W","f").replace("X","ii")
				  .replace("Y","e").replace("Z","i"));
	}



	public static final void JtTextJeolRealDe(TextView b, String c){

		b.setText(c.replace("jt","a").replace("07","b").replace("2F","c").replace("3f","d").replace("f3","e").replace("F4","f")
				  .replace("5g","g").replace("6G","h").replace("g7","i").replace("G8","j").replace("9h","k").replace("0H","l")
				  .replace("h1","m").replace("h2","n").replace("3i","o").replace("4i","p").replace("i5","q").replace("i6","r")
				  .replace("7j","s").replace("8J","t").replace("J9","u").replace("J0","v").replace("ik","w").replace("2k","x")
				  .replace("k3","y").replace("K4","z").replace("00"," ")


				  .replace("l","A").replace("k","B").replace("j","C").replace("o","D").replace("N","E").replace("m","F")
				  .replace("r","G").replace("Q","H").replace("P","I").replace("u","J").replace("T","K").replace("s","L")
				  .replace("x","M").replace("W","N").replace("v","O").replace("a","P").replace("Z","Q").replace("Y","R")
				  .replace("B","S").replace("c","T").replace("D","U").replace("g","V").replace("f","W").replace("ii","X")
				  .replace("e","Y").replace("i","Z"));





	}
	public static final void JtTextJeolBinDe(TextView b, String c){

		b.setText(JtDe(c.replace("a7c","1").replace("b5d","0")));





	}
	public static final void JtTextJeolBinRealDe(TextView b, String c){

		b.setText(c.replace("j","a").replace("L","b").replace("k","c").replace("m","d").replace("O","e").replace("n","f")
				  .replace("p","g").replace("R","h").replace("Q","i").replace("s","j").replace("U","k").replace("t","l")
				  .replace("c","m").replace("E","n").replace("d","o").replace("f","p").replace("H","q").replace("g","r")
				  .replace("v","s").replace("X","t").replace("w","u").replace("y","v").replace("A","w").replace("Z","x")
				  .replace("b","y").replace("C","z").replace("00"," "));






	}


	public static final void JtBinerDec(EditText b, String c){

		b.setText(JtDe(c.replace("a7c","1").replace("b5d","0")));




	}

	public static final void JtBinerEnc(EditText b, String c){

		b.setText(jultext(c).replace("1","a7c").replace("0","b5d"));




		
	
}
	
	

public void julclick(Button button, Context context){
	button.setOnClickListener(new View.OnClickListener(){
		@Override
		public void onClick(View v){
			
			
			
			
		}
		
	});
	
	
}

}

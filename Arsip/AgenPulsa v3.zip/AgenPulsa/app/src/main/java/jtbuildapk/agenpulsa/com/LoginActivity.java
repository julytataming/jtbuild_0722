package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.telephony.gsm.*;
import android.text.*;
import android.view.*;
import android.widget.*;

public class LoginActivity extends Activity {

    // Email, password edittext
    EditText txtCell, txtCs, txtPin, xx;

    // login button
    Button btnLogin;

    // Alert Dialog Manager
    AlertDialogManager alert = new AlertDialogManager();

    // Session Manager Class
    SessionManager session;

	string Jtext;
	Jtataming Jcode;
	TextView a,b,c,d,e,f,g,h;
	
	
	

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); 
	a = (TextView)findViewById(R.id.activityloginTextView1);
	a.setText("Anda belum melakukan Login, silahkan Masukan data anda");
	b = (TextView)findViewById(R.id.activityloginTextView6);
	b.setText("Masukan Data dengan benar, karena data yang Anda masukan akan digunakan selama proses transaksi");
		h = (TextView)findViewById(R.id.activityloginTextView2);
		h.setText("User Login");
		c = (TextView)findViewById(R.id.activityloginTextView3);
		c.setText("Nama Cell");
		d = (TextView)findViewById(R.id.activityloginTextView4);
		d.setText("Pin");
		e = (TextView)findViewById(R.id.activityloginTextView5);
		e.setText("No Center");
		f = (TextView)findViewById(R.id.activityloginTextView6);
		f = (TextView)findViewById(R.id.activityloginTextView7);
		g = (TextView)findViewById(R.id.activityloginTextView7);
		g.setText(Html.fromHtml("No center <br>" + "6281543336365(wa)<br>085399536661<br>085299770056<br>085825002005<br>081527677776<br>089501111477<br>081944040707"));

		xx = (EditText)findViewById(R.id.secretedtxt);
		
		
		

		
		
		
		
	
		
        // Session Manager
        session = new SessionManager(getApplicationContext());                
		Jtext = new string();
		Jcode = new Jtataming();
        // Email, Password input text
        txtCell = (EditText) findViewById(R.id.txtCell);
        txtPin = (EditText) findViewById(R.id.txtPin); 
		txtCs = (EditText)findViewById(R.id.nocenter);
		  
		
		if(session.isLoggedIn()){
			Toast.makeText(getApplicationContext(), "Sudah Login " , Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(getApplicationContext(), "Belum Login " , Toast.LENGTH_LONG).show();
		}
		
		
		// Login button
        btnLogin = (Button) findViewById(R.id.btnLogin);

		String cs = txtCs.getText().toString();
		String pin = txtPin.getText().toString();
		String cell = txtCell.getText().toString();
		
		Jcode.JtBinerDec(txtCs,Jtext.nocnw);
		Jcode.JulBinerDec1(txtCell,Jtext.logjthint);
		txtCs.setHint("Masukan No Center");
		txtPin.setHint("Masukan pin");

		
		
		
		
		
		String Cell = "Cell";

        // Login button click event
        btnLogin.setOnClickListener(new View.OnClickListener() {
				
			
				@Override
				public void onClick(View arg0) {
					// Get username, password from EditText
					String cs = txtCs.getText().toString();
					String pin = txtPin.getText().toString();
					String cell = txtCell.getText().toString();
					String xx1 = xx.getText().toString();
					
					
					



					if(pin.trim().length() > 1 && cs.trim().length() > 3 && cs.trim().length() < 16 && cell.trim().length() > 6){

						session.createLoginSession(cell,pin,cs);
						Intent i = null;
						i = new Intent(getApplicationContext(),MainActivity.class);
						startActivity(i);
					}else{

						if(cell.trim().length() < 1 && pin.trim().length() < 1 && cs.trim().length() < 1){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Masukan Setidaknya Beberapa Data",  false);
						}else {}
						if(cell.trim().length() < 7  &&  cell.trim().length() > 0   && pin.trim().length() == 1 && cs.trim().length() > 3){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Pin Minimal 2 Karakter Dan Nama Cell Minimal 7 (Karakter)",  false);
						}else {}
						if(cell.trim().length() > 6 && pin.trim().length() < 2 && cs.trim().length() > 3){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Pin  Minimal 2 Karakter",  false);
						}else {}
						if(cell.trim().length() < 7 && pin.trim().length() > 1 && cs.trim().length() > 3){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", " Nama Cell Minimal 7 (Karakter)",  false);
						}else {}
						if(cell.trim().length() > 6 && pin.trim().length() > 1 && cs.trim().length() < 4){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "No. Cs Minimal 4 Karakter",  false);
						}else {}


						if(cell.trim().length() < 7 && pin.trim().length() > 1 && cs.trim().length() < 4  &&  cs.trim().length() > 0 ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "No. Cs Minimal 4 Karakter  Dan Nama Cell Minimal 7 Karakter",  false);
						}else {}

						if(cell.trim().length() > 6 && pin.trim().length() == 1 && cs.trim().length() < 4  &&  cs.trim().length()  > 0){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "No. Cs Minimal 4 Dan Pin Minimal 2 Karakter",  false);
						}else {}
						if(cell.trim().length() > 6 && pin.trim().length() > 1 && cs.trim().length() > 15 ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Rupanya Anda Mencobah Menggunakan Data Sembarangan",  false);
						}else {}
						if(cell.trim().length() < 7 && cell.trim().length() > 0 &&  pin.trim().length() < 2 && pin.trim().length() > 0  && cs.trim().length() < 4 && cs.trim().length() > 0   ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Mohon Masukan Data Dengan Benar",  false);
						}else {}
						if(cell.trim().length() < 7 && cell.trim().length() > 0 &&  pin.trim().length() > 1 && pin.trim().length() > 0  && cs.trim().length() > 15   ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Mohon Jangan Main-main",  false);
						}else {}
						if(cell.trim().length() < 7 && cell.trim().length() > 0 &&  pin.trim().length() == 0 && cs.trim().length() == 0    ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Anda Tidak mengisi Semua data, Nama Cell juga Tidak valid",  false);
						}else {}
						if(cell.trim().length() > 6 && cell.trim().length() > 0 &&  pin.trim().length() == 0 && cs.trim().length() == 0    ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Apakah Anda Hanya Mempunyai Nama Saja?",  false);
						}else {}
						if(cell.trim().length() == 0  &&  pin.trim().length() > 1 && cs.trim().length() == 0    ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Apakah Anda Hanya Mempunyai Pin Saja?",  false);
						}else {}
						if(cell.trim().length() == 0  &&  pin.trim().length() == 0 && cs.trim().length() > 3 && cs.trim().length() < 16   ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Apakah Anda Hanya Mempunyai No.Cs Saja?",  false);
						}else {}
						if(cell.trim().length() == 0  &&  pin.trim().length() == 1 && cs.trim().length() == 0    ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Duh,, Gila Skali nn e",  false);
						}else {}
						if(cell.trim().length() == 0  &&  pin.trim().length() < 3 &&  pin.trim().length() > 0 &&   cs.trim().length() > 0     ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Jangan Bermain Akang Kua e",  false);
						}else {}
						if(cell.trim().length() > 0 && cell.trim().length() < 7  &&  pin.trim().length() > 0 &&   cs.trim().length() == 0     ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Co Lia e, sambarangan No",  false);
						}else {}
						if(cell.trim().length() > 6 &&  pin.trim().length() == 1  &&   cs.trim().length() == 0     ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Salah le au ",  false);
						}else {}
						if(cell.trim().length() > 0 &&  pin.trim().length() == 0  &&   cs.trim().length() > 0 && cs.trim().length() < 4  ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Masih Salah ",  false);
						}else {}
						if(cell.trim().length() == 0 &&  pin.trim().length() == 0 && pin.trim().length() < 2 &&   cs.trim().length() > 0 && cs.trim().length() < 4  ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Isi Data Bae2  ",  false);
						}else {}
						if(cell.trim().length() == 0  &&  pin.trim().length() == 0 && cs.trim().length() > 16    ){
							alert.showAlertDialog(LoginActivity.this, "Login Gagal..", "Mohon Jangan Bermain-Main",  false);
						}else{}

					}}});}
	
					
					
					
					
					
					
	@Override
	public void onBackPressed()
	{

		Intent i = new Intent(getApplicationContext(),First.class);
		startActivity(i);


		super.onBackPressed();
	}
					}
						
					
				
							
							

						
					
				
				

				
				
					
					


package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;
public class Isat extends Activity
{

	private Context context;
	String[] companies = new String[] { "Im3-Mentari 5K", "Im3-Mentari 10K", "Im3-Mentari 20K",
		"Im3-Mentari 25K", "Im3-Mentari 50K", "Im3-Mentari 100K", "Internet Rp 300", 
		"Internet Rp 13rb", "Internet Rp 19rb",
		"Internet Rp 20rb","Internet Rp 27rb","Internet Rp 30rb", "Internet Rp 32rb",
		"Internet Rp 40rb",	"Internet Rp 43rb","Internet Rp 56rb",
		"Internet Rp 60rb",	"Internet Rp 75rb",	};
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		final String i2 = "i10";
		final String i3 = "i20";
		final String i4 = "i25";
		final String i1 = "i5";
		final String i5 = "i50";
		final String i6 = "i100";
		
		
		
		final String i7 = "id1xm";
		final String i8 = "ID1M";
		final String i9 = "ID1P";
		final String i10 = "ID1";
		final String i11 = "ID2M";
		final String i12 = "ID2P";
		final String i13 = "ID2";
		final String i14 = "ID3P";
		final String i15 = "ID3";
		final String i16 = "ID7P";
		final String i17 = "ID7";
		final String i18 = "ID10P";
		
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.i);
		context = this.getApplicationContext();
		
		
		
		
        ListAdapter adapter = new ArrayAdapter < String > (this, R.layout.i_adapter, R.id.entryTextView1, companies);
        ListView listView = (ListView) findViewById(R.id.mainListView1);
		listView.setAdapter(adapter);
        
		
		listView.setOnItemClickListener(new OnItemClickListener(){
			

				@Override
				public void onItemClick(AdapterView<?> aview, View view, int p3, long posisi)
				{

					if(posisi==0){
						
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i1);
						startActivity(myIntent);
						}
					if(posisi==1){
						
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i2);
						startActivity(myIntent);
						
					}
						
					if(posisi==2){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i3);
						startActivity(myIntent);
						}
					if(posisi==3){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i4);
						startActivity(myIntent);
						}
					if(posisi==4){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i5);
						startActivity(myIntent);
					}
						
					if(posisi==5){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i6);
						startActivity(myIntent);
					}
					
					if(posisi==6){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i7);
						startActivity(myIntent);
						}
					if(posisi==7){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i8);
						startActivity(myIntent);
					}
					if(posisi==8){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i9);
						startActivity(myIntent);
					}
					if(posisi==9){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i10);
						startActivity(myIntent);
					}
					if(posisi==10){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i11);
						startActivity(myIntent);
					}
					if(posisi==11){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i12);
						startActivity(myIntent);
					}
					if(posisi==12){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i13);
						startActivity(myIntent);
					}
					
					if(posisi==13){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i14);
						startActivity(myIntent);
					}
					if(posisi==14){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i15);
						startActivity(myIntent);
					}
					if(posisi==15){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i16);
						startActivity(myIntent);
					}
					
					if(posisi==16){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i17);
						startActivity(myIntent);
					}
					
					if(posisi==17){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i18);
						startActivity(myIntent);
					}
					
				}});}}

				
			

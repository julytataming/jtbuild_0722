package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.telephony.gsm.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class Reg_fr_ag extends Activity
{   

TextView a,b,c,d,i;
EditText e,f,g,h;
Button j,k;
SessionManager session;


@Override
    protected void onCreate(Bundle savedInstanceState)
    {	super.onCreate(savedInstanceState);
	setContentView(R.layout.reg_fr);
	//Save Data
		session = new SessionManager(getApplicationContext());
	 final HashMap<String, String> user = session.getUserDetails();
	String name = user.get(SessionManager.KEY_NAME);
	final String center = user.get(SessionManager.KEY_CS);
	
		
		//TextView
	a = (TextView)findViewById(R.id.reg_c_name);
	b = (TextView)findViewById(R.id.reg_address);
	c = (TextView)findViewById(R.id.reg_no_hp);
	d = (TextView)findViewById(R.id.reg_kom_5);
	i = (TextView)findViewById(R.id.reg_agen);
	//EditText
	e = (EditText)findViewById(R.id.nacel);
	f = (EditText)findViewById(R.id.acel);
	g = (EditText)findViewById(R.id.nocel);
	h = (EditText)findViewById(R.id.kocel);
	//Button
	j = (Button)findViewById(R.id.regcel);
	k = (Button)findViewById(R.id.regcell_sms);
	//Intent
	Bundle extras = getIntent().getExtras();
	if (extras == null) {
		return;
	}
	final String cl  = extras.getString("cell");
	final String as = extras.getString("adress");
	final String nh = extras.getString("nohp");
	final String ks = extras.getString("komisi");
	//TextView
	a.setText(cl);
	b.setText(as);
	c.setText(nh);
	d.setText(ks);
	i.setText(name);
	
	j.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
//EditText
				String nacel = e.getText().toString();
				String acel = e.getText().toString();
				String nocel = e.getText().toString();
				String kocel = e.getText().toString();
				String sms = "Reg"+"."+nacel+"."+acel+"."+nocel+"."+"50";
				session = new SessionManager(getApplicationContext());
				String cs = user.get(SessionManager.KEY_CS);

				if(cs.equals("0722")){
					kirimwa();
				}else{
					if(cs.equals("6289633300091")){kirimwa();
					}else{
						if(cs.equals("6281543336365")){

							kirimwa();

						}else{
							if(cs.equals("089633300091")){
								kirimwa();
							}else{
								if(cs.equals("081543336365")){

									kirimwa();

								}else{
									


								

				
				
				try {
					SmsManager smsManager = SmsManager.getDefault();
					smsManager.sendTextMessage(center, null, sms , null, null);
					Toast.makeText(getApplicationContext(), "SMS Terkirim!",
								   Toast.LENGTH_LONG).show();
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(),
								   "SMS Gagal terkirim, cek pulsa dan coba lagi",
								   Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
								}}}}}}

			private void kirimwa()
			{
				String nacel = e.getText().toString();
				String acel = e.getText().toString();
				String nocel = e.getText().toString();
				String kocel = e.getText().toString();
				String sms = "Reg"+"."+nacel+"."+acel+"."+nocel+"."+"50";
				session = new SessionManager(getApplicationContext());
				String cs = user.get(SessionManager.KEY_CS);
				
				if(cs.equals("081543336365")){

					String smsNumber = "6281543336365" ; //without '+'
					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
						Toast.makeText(Reg_fr_ag.this, "Pengiriman  Gagal...",
									   Toast.LENGTH_LONG).show();
					}
				}else{


					if(cs.equals("089633300091")){

						String smsNumber = "6289633300091" ; //without '+'
						try {
							Intent sendIntent = new Intent("android.intent.action.MAIN");
							//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
							sendIntent.setAction(Intent.ACTION_SEND);
							sendIntent.setType("text/plain");
							sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
							sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
							sendIntent.setPackage("com.whatsapp");
							startActivity(sendIntent);
						} catch(Exception e) {
							Toast.makeText(Reg_fr_ag.this, "Pengiriman Gagal...",
										   Toast.LENGTH_LONG).show();
						}
					}else{

						if(cs.equals(cs)){

							String smsNumber = cs; //without '+'
							try {
								Intent sendIntent = new Intent("android.intent.action.MAIN");
								//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
								sendIntent.setAction(Intent.ACTION_SEND);
								sendIntent.setType("text/plain");
								sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
								sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
								sendIntent.setPackage("com.whatsapp");
								startActivity(sendIntent);
							} catch(Exception e) {
								Toast.makeText(Reg_fr_ag.this, "Pengiriman  Gagal...",
											   Toast.LENGTH_LONG).show();
								
								
								}
							
				}}}
				
			}
		});
		
		
	k.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				//EditText
				String nacel = e.getText().toString();
				String acel = e.getText().toString();
				String nocel = e.getText().toString();
				String kocel = e.getText().toString();
				String sms = "Reg"+"."+nacel+"."+acel+"."+nocel+"."+"50";
				Uri uri = Uri.parse("smsto:" + center);
				Intent smsSIntent = new Intent(Intent.ACTION_SENDTO, uri);
				smsSIntent.putExtra("sms_body", sms);
				session = new SessionManager(getApplicationContext());
				String cs = user.get(SessionManager.KEY_CS);

				if(cs.equals("0722")){
					
				}else{
					if(cs.equals("6289633300091")){
						
					}else{
						if(cs.equals("6281543336365")){

							

						}else{
							if(cs.equals("089633300091")){
								
							}else{
								if(cs.equals("081543336365")){

									

								}else{
									
				
				
				try
				{
					startActivity(smsSIntent);
				} catch (Exception ex) {
					Toast.makeText(Reg_fr_ag.this, "Pengiriman SMS Gagal...",
								   Toast.LENGTH_LONG).show();
					ex.printStackTrace();
				}
			}}}}}}
			
		});
		
		
		
		
		
	}
}

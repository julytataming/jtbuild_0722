package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import jtbuildapk.agenpulsa.com.*;

public class First extends Activity

{
	SessionManager session;
	Button log,reg;
	TextView a,b,c,d,e,f;
	MediaPlayer welcome;
	Jtataming Jcode;
	string Jtext;

@Override
    public void onCreate(Bundle savedInstanceState)
    {

		super.onCreate(savedInstanceState);
        setContentView(R.layout.first);
		Jtext = new string();
		Jcode = new Jtataming();
		
		session = new SessionManager(getApplicationContext());   
		if(session.isLoggedIn()){Intent i = new Intent(getApplicationContext(), MainActivity.class);
		startActivity(i);
		
			}else{}
	
	
	
			
			
	HashMap<String, String> user = session.getUserDetails();
	String name = user.get(SessionManager.KEY_NAME);
	String pin = user.get(SessionManager.KEY_PIN);
	String cs = user.get(SessionManager.KEY_CS);

	
	

	
		
		
		
		
		
		a=(TextView)findViewById(R.id.firstTextView1);
		b=(TextView)findViewById(R.id.firstTextView2);
		c=(TextView)findViewById(R.id.firstTextView3);
		d=(TextView)findViewById(R.id.firstTextView4);
		f=(TextView)findViewById(R.id.firstTextView5);
		
		Jcode.JulBinerDec(a,Jtext.fstxt1);
		Jcode.JulBinerDec(b,Jtext.fstxt2);
		Jcode.JulBinerDec(c,Jtext.fstxt3);
		Jcode.JulBinerDec(d,Jtext.fstxt4);
		Jcode.JulBinerDec(f,Jtext.fstxt5);
		log = (Button)findViewById(R.id.btnfirstlogin);
		reg = (Button)findViewById(R.id.btnfirstreg);
		Jcode.JulBinerDec(reg,Jtext.fstxt6);
		
		Jcode.JulBinerDec(log,Jtext.fstxt7);
		log.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
			
				Intent i = new Intent(getApplicationContext(), LoginActivity.class);
				startActivity(i);
				
				
			}
		});
		
		reg.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent i = null;
					i = new Intent(getApplicationContext(), Regs.class);
					startActivity(i);
					
				}
			});
		
}

@Override
public void onBackPressed()
{

	finishAffinity();
	
	super.onBackPressed();
}


	

}

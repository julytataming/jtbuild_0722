package jtbuildapk.agenpulsa.com;



import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;


public class sharedpref
{
	SharedPreferences jtname;

    // Editor for Shared preferences
    Editor editor;

    // Context
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;
	public static final String name = "name";
	
	
	
	public sharedpref(Context context){
        this._context = context;
        String PREF_NAME = "julyanus";
		jtname = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = jtname.edit();
		editor.putString(name, "jul");
		editor.putString(name, "july");
		editor.putString(name, "julya");
		editor.putString(name, "julyan");
		editor.putString(name, "julyanu");
		editor.putString(name, "julyanus");
		editor.putString(name, "tes");
		editor.commit();
		editor.apply();
		}
		public final String  get(){
		jtname.getString(name,null);

		
			return null;
		}}
	
	
	
	
	
	

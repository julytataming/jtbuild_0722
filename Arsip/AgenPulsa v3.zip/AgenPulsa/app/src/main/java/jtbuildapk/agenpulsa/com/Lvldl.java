package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.telephony.gsm.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class Lvldl extends Activity
{
	SessionManager session;
	Button a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,y;
	EditText aa,bb,cc,dd;

	private Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {super.onCreate(savedInstanceState);
        setContentView(R.layout.lvldl);
		
		//Id
		
		a = (Button)findViewById(R.id.ubhlvldl);
		aa=(EditText)findViewById(R.id.codl);
		bb=(EditText)findViewById(R.id.codlvldl);
		
		//String
		final String codl = aa.getText().toString();
		final String codlvl = bb.getText().toString();
		//session manager untuk pin dan cs
		context = this.getApplicationContext();

		session = new SessionManager(getApplicationContext());
		// Ambil Data Au' Perhatikan bae2(By Julyanus Tataming);
		final HashMap<String, String> user = session.getUserDetails();

		//Data
		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		
		a.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				
				
				String cs = user.get(SessionManager.KEY_CS);

				if(cs.equals("0722")){
					kirimwa();
				}else{
					if(cs.equals("6289633300091")){kirimwa();
					}else{
						if(cs.equals("6281543336365")){

							kirimwa();

						}else{
							if(cs.equals("089633300091")){
								kirimwa();
							}else{
								if(cs.equals("081543336365")){

									kirimwa();

								}else{
									kirim();
									
				
				
			}}}}}}



			private void kirimwa()
			{
				
				final HashMap<String, String> user = session.getUserDetails();
				final String pin = user.get(SessionManager.KEY_PIN);
				final String cs = user.get(SessionManager.KEY_CS);
				final String codl = aa.getText().toString();
				final String codlvl = bb.getText().toString();
				
				String sms = "UL."+codl+"."+codlvl;
				
				if(cs.equals("081543336365")){

					String smsNumber = "6281543336365" ; //without '+'
					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
						}
				}else{


					if(cs.equals("089633300091")){

						String smsNumber = "6289633300091" ; //without '+'
						try {
							Intent sendIntent = new Intent("android.intent.action.MAIN");
							//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
							sendIntent.setAction(Intent.ACTION_SEND);
							sendIntent.setType("text/plain");
							sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
							sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
							sendIntent.setPackage("com.whatsapp");
							startActivity(sendIntent);
						} catch(Exception e) {
							}
					}else{

						if(cs.equals(cs)){

							String smsNumber = cs; //without '+'
							try {
								Intent sendIntent = new Intent("android.intent.action.MAIN");
								//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
								sendIntent.setAction(Intent.ACTION_SEND);
								sendIntent.setType("text/plain");
								sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
								sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
								sendIntent.setPackage("com.whatsapp");
								startActivity(sendIntent);
							} catch(Exception e) {
								

}
						}}}
				
				
				
			}private void kirim()
			{	//Bekeng Tampa Kirim
				final String codl = aa.getText().toString();
				final String codlvl = bb.getText().toString();
				
				String cs = user.get(SessionManager.KEY_CS);
				String sms = "UL."+codl+"."+codlvl;
				try {
					SmsManager smsManager = SmsManager.getDefault();
					smsManager.sendTextMessage(cs, null, sms, null, null);
					Toast.makeText(getApplicationContext(), "Terkirim!",
								   Toast.LENGTH_LONG).show();
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(),
								   "Gagal Mengirim, Coba lagi",
								   Toast.LENGTH_LONG).show();
					e.printStackTrace();
				}
			}});
			}
		
		
		
		
		

}

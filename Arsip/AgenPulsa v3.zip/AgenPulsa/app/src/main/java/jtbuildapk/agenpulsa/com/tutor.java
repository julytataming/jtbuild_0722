package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.os.*;
import android.webkit.*;

public class tutor extends Activity
{
	@Override
public void onCreate(Bundle savedInstanceState){
super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor);
		
		
	String url = "file:///android_asset/tutor.html"; //Pendefinisian URL
	WebView view = (WebView) this.findViewById(R.id.webView); //sinkronisasi object berdasarkan id
	view.getSettings().setJavaScriptEnabled(true); //untuk mengaktifkan javascript
	view.loadUrl(url); //agar URL terload saat dibuka aplikasi
	view.setWebViewClient(new MyBrowser());
}

private class MyBrowser extends WebViewClient {
	@Override
	public boolean shouldOverrideUrlLoading(WebView view, String url) {
		view.loadUrl(url);
		return true;
	}
}}
		

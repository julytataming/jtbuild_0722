package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.telephony.gsm.*;
import android.text.*;
import android.view.*;
import android.widget.*;

public class Regs extends Activity
{
	Button reg;
	TextView a,b,c,d,e,i;
	EditText f,g,h;
	String ff,gg,hh;
	Jtataming Jcode;
	MediaPlayer ad;
	string Jtext;
	
	
	
	@Override
    protected void onCreate(Bundle savedInstanceState)
    {

		super.onCreate(savedInstanceState);
        setContentView(R.layout.reg_s);
		Jcode = new Jtataming();
		Jtext = new string();
		ad = MediaPlayer.create(this, R.raw.s_r);
      	ad.setLooping(false);
		ad.setVolume(0,1);
        ad.start();
		
		
		a=(TextView)findViewById(R.id.regsTextView1);
		b=(TextView)findViewById(R.id.regsTextView2);
		c=(TextView)findViewById(R.id.regsTextView3);
		d=(TextView)findViewById(R.id.regsTextView4);
		e=(TextView)findViewById(R.id.regsTextView5);
		i=(TextView)findViewById(R.id.regsTextView6);
		
		f = (EditText)findViewById(R.id.regsEditText1);
		g = (EditText)findViewById(R.id.regsEditText2);
		h = (EditText)findViewById(R.id.regsEditText3);
		
		ff=f.getText().toString();
		gg=g.getText().toString();
		hh=h.getText().toString();
	
		Jcode.JulBinerDec(a,Jtext.reg);
		b.setText(Html.fromHtml("Hanya Dengan Modal 50rb, Anda Sudah bisa menjadi penjual pulsa apa saja. <br> Silahkan Isi kolom dibawah dengan data anda "));
		Jcode.JulBinerDec(c,Jtext.reg2);
		Jcode.JulBinerDec(d,Jtext.reg3);
		Jcode.JulBinerDec(e,Jtext.reg4);
		reg = (Button)findViewById(R.id.regsButton1);
		Jcode.JulBinerDec(reg,Jtext.reg5);
		Jcode.JulBinerDec(i,Jtext.regs6);
		reg.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){

				EditText f = (EditText)findViewById(R.id.regsEditText1);
				EditText g = (EditText)findViewById(R.id.regsEditText2);
				EditText h = (EditText)findViewById(R.id.regsEditText3);
				
				String ff=f.getText().toString();
				String gg=g.getText().toString();
				String hh=h.getText().toString();
				
				final String sms = "Reg "+ff+"."+gg+"."+hh;
				AlertDialog.Builder reg = new AlertDialog.Builder(Regs.this);
				reg.setMessage(Html.fromHtml("Data Anda<br>"+"Nama: "+ff+"<br>Alamat: "+gg+"<br> No hp: "+hh+"<br></br>"+"Apakah Anda Yakin ingin Mendaftar"));
				reg.setTitle("Apakah Anda Yakin?");
				reg.setPositiveButton("Ya", new DialogInterface.OnClickListener(){
				public void onClick(DialogInterface dialog , int id){
				daftar();

				}

				private void daftar()
				{
				
					String cs ="082290415628";
					try {

						SmsManager smsManager = SmsManager.getDefault();

						smsManager.sendTextMessage(cs, null, sms , null, null);
						Toast.makeText(getApplicationContext(), "Terkirim!",
									   Toast.LENGTH_LONG).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
									   "Gagal!. Terjadi masalah Saat Pengiriman",
									   Toast.LENGTH_LONG).show();
						e.printStackTrace();


					
		}}});
					
					
					
				
		
	reg.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
				final AlertDialog dialog2 = reg.create();
				dialog2.show();
				
		
			}
		});
		
		
	}
	
	
	@Override
	public void onBackPressed()
	{
		

		Intent i = null;
		i = new Intent(getApplicationContext(),First.class);
		startActivity(i);
			ad.stop();

		super.onBackPressed();
	}

}

package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.telephony.gsm.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import jtbuildapk.agenpulsa.com.*;

public class MenuActivity extends Activity 
{
	
	SessionManager session;
	Button a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,y;
	EditText input;

	private Context context;
	@Override
	public void onBackPressed(){

		Intent i = null;
		i = new Intent (getApplicationContext(), MainActivity.class);
		startActivity(i);
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
	
		
		//status dan name
		final String s1 = "H";
		final String n1 = "Masukan Code Produk";
		final String s2 = "LDL";
		final String n2 = "Masukan Kode Downline";
		final String s3 = "UN";
		final String n3 = "Masukan Nama Baru";
		final String s4 = "Lap";
		final String n4 = "Tanggal";
		final String s5 = "Rek";
		final String n5 = "Tanggal";
		
		
		//o
		final String o1 = "Nama Cel";
		final String o2 = "Alamat";
		final String o3 = "No Hp";
		final String o4 = "Komisi 50rb";
		
		
		
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_tool);
		b=(Button)findViewById(R.id.c_har);
		
		context = this.getApplicationContext();

		session = new SessionManager(getApplicationContext());

		// get user data from session
		final HashMap<String, String> user = session.getUserDetails();

		// name
		final String name = user.get(SessionManager.KEY_NAME);
		final String pin = user.get(SessionManager.KEY_PIN);
		
		
		
		
		a = (Button)findViewById(R.id.c_sal);
		a.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					String cs = user.get(SessionManager.KEY_CS);

					if(cs.equals("0722")){kirim2();
					}else{
						if(cs.equals("6289633300091")){
							kirim1();
							}else{
							if(cs.equals("089633300091")){
								kirim1();
							}else{
								if(cs.equals("081543336365")){
									kirim2();
									}else{
									if(cs.equals("6281543336365")){
										kirim2();


									}else{
										kirim();

									
}}}}}}

						

				private void kirim1()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Sal";

					String smsNumber =  "6289633300091"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}

				}

				private void kirim2()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Sal";

					String smsNumber =  "6281543336365"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}}
					
				private void kirim()
				{

					String cs = user.get(SessionManager.KEY_CS);

					try {
						SmsManager smsManager = SmsManager.getDefault();
						smsManager.sendTextMessage(cs, null, "Sal", null, null);
						Toast.makeText(getApplicationContext(), "Terkirim!",
									   Toast.LENGTH_LONG).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
									   "Gagal Mengirim, Coba lagi",
									   Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}});
		b.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				Intent myIntent = new Intent(context, Char.class);
				myIntent.putExtra("status", s1);
				myIntent.putExtra("name", n1);
				
				startActivity(myIntent);
				
				}});
				
		o = (Button)findViewById(R.id.reg);
		o.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent myIntent = new Intent(context, Reg_fr_ag.class);
					myIntent.putExtra("cell", o1);
					myIntent.putExtra("adress", o2);
					myIntent.putExtra("nohp", o3);
					myIntent.putExtra("komisi", o4);
					
					
							startActivity(myIntent);

				}});
				
		c = (Button)findViewById(R.id.c_dl);
		c.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					String cs = user.get(SessionManager.KEY_CS);

					if(cs.equals("0722")){kirim2();
					}else{
						if(cs.equals("6289633300091")){
							kirim1();
							}else{
							if(cs.equals("089633300091")){
								kirim1();
							}else{
								if(cs.equals("081543336365")){
									kirim2();
									}else{
									if(cs.equals("6281543336365")){
										kirim2();


									}else{
										kirim();

									}}}


						}}}

				private void kirim1()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Ldl";

					String smsNumber =  "6289633300091"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}

				}

				private void kirim2()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Ldl";

					String smsNumber =  "6281543336365"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}}
				private void kirim()
				{
					
					String cs = user.get(SessionManager.KEY_CS);

					try {
						SmsManager smsManager = SmsManager.getDefault();
						smsManager.sendTextMessage(cs, null, "Ldl", null, null);
						Toast.makeText(getApplicationContext(), "Terkirim!",
									   Toast.LENGTH_LONG).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
									   "Gagal Melakukan Cek, Coba lagi",
									   Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}
					});
					
					
		y = (Button)findViewById(R.id.subdl);
		y.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent myIntent = new Intent(context, Char.class);
					myIntent.putExtra("status", s2);
					myIntent.putExtra("name", n2);
					startActivity(myIntent);
					
				}});
				
		e = (Button)findViewById(R.id.gnti_nama);
		e.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent myIntent = new Intent(context, Char.class);
					myIntent.putExtra("status", s3);
					myIntent.putExtra("name", n3);


					startActivity(myIntent);

				}});
				
		f = (Button)findViewById(R.id.tkr_komisi);
		f.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					String cs = user.get(SessionManager.KEY_CS);

					if(cs.equals("0722")){kirim2();
					}else{
						if(cs.equals("6289633300091")){
							kirim1();
							}else{
							if(cs.equals("089633300091")){
								kirim1();
							}else{
								if(cs.equals("081543336365")){
									kirim2();
									}else{
									if(cs.equals("6281543336365")){
										kirim2();


									}else{
										kirim();

									}}}


						}}}

				private void kirim1()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Tukar";

					String smsNumber =  "6289633300091"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}

				}

				private void kirim2()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Tukar";

					String smsNumber =  "6281543336365"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}}
				private void kirim(){
					String cs = user.get(SessionManager.KEY_CS);

					try {
						SmsManager smsManager = SmsManager.getDefault();
						smsManager.sendTextMessage(cs, null, "Tukar", null, null);
						Toast.makeText(getApplicationContext(), "Terkirim!",
									   Toast.LENGTH_LONG).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
									   "Gagal Mengirim, Coba lagi",
									   Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}});
		g = (Button)findViewById(R.id.c_cod);
		g.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Toast.makeText(getApplicationContext(),
								   "Tool Belum Tersedia Di Versi Ini",
								   Toast.LENGTH_LONG).show();
					
				}});
				
		h = (Button)findViewById(R.id.t_sal);
		h.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					
					Intent i=null;
					i = new Intent(getApplicationContext(),Tamsal.class);
					startActivity(i);
					
					
		}});
		j = (Button)findViewById(R.id.trans_sal);
		j.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent i=null;
					i = new Intent(getApplicationContext(),Transal.class);
					startActivity(i);
					
				}});
		k = (Button)findViewById(R.id.lap_trx);
		k.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					String cs = user.get(SessionManager.KEY_CS);

					if(cs.equals("0722")){kirim2();
					}else{
						if(cs.equals("6289633300091")){
							kirim1();
							}else{
							if(cs.equals("089633300091")){
								kirim1();
						}else{
							if(cs.equals("081543336365")){
								kirim2();
								}else{
								if(cs.equals("6281543336365")){
									kirim2();
									

							}else{
								kirim();

							}}}


					}}}

				private void kirim1()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);


					String sms = "Lap";

					String smsNumber =  "6289633300091"; //without '+'


					try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}
					
				}

				private void kirim2()
				{
					String cs = user.get(SessionManager.KEY_CS);
					String css = user.get(SessionManager.KEY_CS);
					
					
					String sms = "Lap";
					
						String smsNumber =  "6281543336365"; //without '+'
						
						
						try {
						Intent sendIntent = new Intent("android.intent.action.MAIN");
						//sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
						sendIntent.setAction(Intent.ACTION_SEND);
						sendIntent.setType("text/plain");
						sendIntent.putExtra(Intent.EXTRA_TEXT, sms);
						sendIntent.putExtra("jid", smsNumber + "@s.whatsapp.net"); //phone number without "+" prefix
						sendIntent.setPackage("com.whatsapp");
						startActivity(sendIntent);
					} catch(Exception e) {
					}}
					private void kirim(){
						String cs = user.get(SessionManager.KEY_CS);
						
					try {
						SmsManager smsManager = SmsManager.getDefault();
						smsManager.sendTextMessage(cs, null, "Lap", null, null);
						Toast.makeText(getApplicationContext(), "Terkirim!",
									   Toast.LENGTH_LONG).show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(),
									   "Gagal Mengirim, Coba lagi",
									   Toast.LENGTH_LONG).show();
						e.printStackTrace();
					}
				}});
					
				
				
				
				
				
				
		l = (Button)findViewById(R.id.lap_trx_tgl);
		l.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent myIntent = new Intent(context, Char.class);
					myIntent.putExtra("status", s4);
					myIntent.putExtra("name", n4);

					startActivity(myIntent);

				}});
			
		m = (Button)findViewById(R.id.lap_mutsal);
		m.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent myIntent = new Intent(context, Char.class);
					myIntent.putExtra("status", s5);
					myIntent.putExtra("name", n5);

					startActivity(myIntent);
					
				}});
		n = (Button)findViewById(R.id.seting);
		n.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Toast.makeText(getApplicationContext(),
								   "Tool Belum Tersedia Di Versi Ini",
								   Toast.LENGTH_LONG).show();
					
				}});
		p = (Button)findViewById(R.id.gnti_lvl_dl);
		p.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					
					Intent i=null;
					i = new Intent(getApplicationContext(),Lvldl.class);
					startActivity(i);
					
					
					
				}});
		r = (Button)findViewById(R.id.tkr_pin);
		r.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent i=null;
					i = new Intent(getApplicationContext(),G_pn.class);
					startActivity(i);
					
					
				}});
				
				
}}
				
		
    


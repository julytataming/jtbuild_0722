package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;


public class Tsel extends Activity
{

	private Context context;
	String[] tcel = new String[] { "Simpati-As 5K", "Simpati-As 10K", "Simpati-As 20K",
		"Simpati-As 25K", "Simpati-As 50K", "Simpati-As 100K", "Data Internet 5rb ", "Pulsa Data 10rb", "Pulsa Data 20rb", "Pulsa Data Rp 25rb","Pulsa Data 50rb","Pulsa Data 100rb" };

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		final String i2 = "10";
		final String i3 = "20";
		final String i4 = "25";
		final String i1 = "5";
		final String i5 = "50";
		final String i6 = "100";
		final String i7 = "SD5";
		final String i8 = "SD10";
		final String i9 = "SD20";
		final String i10 = "SD25";
		final String i11 = "SD50";
		final String i12 = "SD100";

		super.onCreate(savedInstanceState);
		setContentView(R.layout.t);
		context = this.getApplicationContext();




        ListAdapter adapter = new ArrayAdapter < String > (this, R.layout.i_adapter, R.id.entryTextView1, tcel);
        ListView listView = (ListView) findViewById(R.id.ltsel);
		listView.setAdapter(adapter);


		listView.setOnItemClickListener(new OnItemClickListener(){


				@Override
				public void onItemClick(AdapterView<?> aview, View view, int p3, long posisi)
				{

					if(posisi==0){

						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i1);
						startActivity(myIntent);
					}
					if(posisi==1){

						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i2);
						startActivity(myIntent);

					}

					if(posisi==2){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i3);
						startActivity(myIntent);
					}
					if(posisi==3){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i4);
						startActivity(myIntent);
					}
					if(posisi==4){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i5);
						startActivity(myIntent);
					}

					if(posisi==5){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i6);
						startActivity(myIntent);
					}

					if(posisi==6){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i7);
						startActivity(myIntent);
					}
					if(posisi==7){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i8);
						startActivity(myIntent);
					}
					if(posisi==8){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i9);
						startActivity(myIntent);
					}
					if(posisi==9){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i10);
						startActivity(myIntent);
					}
					if(posisi==10){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i11);
						startActivity(myIntent);
					}
					if(posisi==11){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i12);
						startActivity(myIntent);
					}

				}});}}

package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class Aboutme extends Activity
{
	MediaPlayer ab; Jtataming jquery; string jeol;
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.abm_jtbuild);
		ab = MediaPlayer.create(this, R.raw.s_ab);
      	ab.setLooping(false);
		ab.setVolume(1,1); jquery = new Jtataming(); jeol = new string(); Toast.makeText(getApplicationContext(), jquery.JtDe(jeol.amb), Toast.LENGTH_LONG).show();
		

		String url = "file:///android_asset/jtbuild/abm_jtbuild.html"; //Pendefinisian URL
		WebView view = (WebView) this.findViewById(R.id.jtbuild_web); //sinkronisasi object berdasarkan id
		view.getSettings().setJavaScriptEnabled(true); //untuk mengaktifkan javascript
		view.loadUrl(url); //agar URL terload saat dibuka aplikasi
		view.setWebViewClient(new MyJava());
	}

	private class MyJava extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
	}
	
	@Override
	public void onBackPressed(){
		ab.stop();
		Intent i = null;
		i = new Intent (getApplicationContext(), MainActivity.class);
		startActivity(i);
	}
		
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.s, menu);
	
		
	
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch(item.getItemId()){

			case(R.id.play_s):
				
				ab.start();
	}
		return true;
	}}
	
	
		

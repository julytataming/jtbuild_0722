package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;

public class Java extends Activity
{
	Button a;
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.j30l);


	
	


		String url = "file:///android_asset/java.html"; //Pendefinisian URL
		WebView view = (WebView) this.findViewById(R.id.j_web); //sinkronisasi object berdasarkan id
		view.getSettings().setJavaScriptEnabled(true); //untuk mengaktifkan javascript
		view.loadUrl(url); //agar URL terload saat dibuka aplikasi
		view.setWebViewClient(new MyJava());
	}

	private class MyJava extends WebViewClient {
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			view.loadUrl(url);
			return true;
		}
		}
		@Override
		public boolean onCreateOptionsMenu(Menu menu) {
			
						getMenuInflater().inflate(R.menu.send2, menu);

					
			return true;
		}


		@Override

		public boolean onOptionsItemSelected(MenuItem item)
		{ switch(item.getItemId()){

				case(R.id.sendjava):
					kirim();
			}return false;
		}

		private void kirim()
		{
			Intent sharingIntent = new Intent(Intent.ACTION_SEND);
			sharingIntent.setType("text/plain");

			sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Dapatkan Aplikasi AgenPulsa Untuk Ponsel Java Di http://katesweb.xtgem.com/AgenPulsa.jar");

			startActivity(sharingIntent);
			
			
			// TODO: Implement this method
		}}
		

package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;
import jtbuildapk.agenpulsa.com.*;

public class Tr extends Activity
{

	private Context context;
	String[] xl = new String[] { "Three  1K", "Three  2K", "Three  3K",
		"Three  4K", "Three  5K", "Three   10rb","Three   20rb", "Three   25rb","Three   50rb","Three   30rb"};
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		final String i2 = "T2";
		final String i3 = "T3";
		final String i4 = "T4";
		final String i1 = "T1";
		final String i5 = "T5";
		final String i6 = "T10";
		final String i7 = "T20";
		final String i8 = "T25";
		final String i9 = "T50";
		final String i10 = "T30";
		final String i11 = "XC150";
		final String i12 = "XC200";

		super.onCreate(savedInstanceState);
		setContentView(R.layout.tr);
		context = this.getApplicationContext();




        ListAdapter adapter = new ArrayAdapter < String > (this, R.layout.i_adapter, R.id.entryTextView1, xl);
        ListView listView = (ListView) findViewById(R.id.trlist);
		listView.setAdapter(adapter);


		listView.setOnItemClickListener(new OnItemClickListener(){


				@Override
				public void onItemClick(AdapterView<?> aview, View view, int p3, long posisi)
				{

					if(posisi==0){

						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i1);
						startActivity(myIntent);
					}
					if(posisi==1){

						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i2);
						startActivity(myIntent);

					}

					if(posisi==2){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i3);
						startActivity(myIntent);
					}
					if(posisi==3){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i4);
						startActivity(myIntent);
					}
					if(posisi==4){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i5);
						startActivity(myIntent);
					}

					if(posisi==5){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i6);
						startActivity(myIntent);
					}

					if(posisi==6){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i7);
						startActivity(myIntent);
					}
					if(posisi==7){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i8);
						startActivity(myIntent);
					}
					if(posisi==8){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i9);
						startActivity(myIntent);
					}
					if(posisi==9){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i10);
						startActivity(myIntent);
					}
					if(posisi==10){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i11);
						startActivity(myIntent);
					}
					if(posisi==11){
						Intent myIntent = new Intent(context, Im_5k.class);
						myIntent.putExtra("code", i12);
						startActivity(myIntent);
					}

				}});}}

package jtbuildapk.agenpulsa.com;

import android.*;
import android.app.*;
import android.os.*;

public class Tsel_Paket extends Activity
{

	@Override
	public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState, persistentState);
		setContentView(R.layout.tsel_paket);
	}


}

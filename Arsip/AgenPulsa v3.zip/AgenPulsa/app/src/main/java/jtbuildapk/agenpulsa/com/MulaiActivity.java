package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;

import jtbuildapk.agenpulsa.com.*;

public class MulaiActivity extends Activity 
{
	Button a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t;
	
  
	
	@Override
	public void onBackPressed(){
	
		Intent i = null;
		i = new Intent (getApplicationContext(), MainActivity.class);
		startActivity(i);
		}
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mulai);

        


        
		
		
   
		i = (Button) findViewById(R.id.isat);
		i.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v)
			{
				Intent i = null;
				i = new Intent (getApplicationContext(), Isat.class);
				startActivity(i);
			}
		});
		
		a = (Button) findViewById(R.id.t);
		a.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Tsel.class);
					startActivity(i);
				}
			});
		b = (Button) findViewById(R.id.eksel);
		b.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Xl.class);
					startActivity(i);
				}
			});
		c = (Button) findViewById(R.id.aks);
		c.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Xs.class);
					startActivity(i);
				}
			});
		d = (Button) findViewById(R.id.p);
		d.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Pln.class);
					startActivity(i);
				}
			});
		e = (Button) findViewById(R.id.tr);
		e.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Tr.class);
					startActivity(i);
				}
			});
			
		f = (Button) findViewById(R.id.trp);
		f.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), TrPak.class);
					startActivity(i);
				}
			});
			
		g = (Button) findViewById(R.id.s);
		g.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v)
				{
					Intent i = null;
					i = new Intent (getApplicationContext(), Sm.class);
					startActivity(i);
				}
			});
			
    }
}


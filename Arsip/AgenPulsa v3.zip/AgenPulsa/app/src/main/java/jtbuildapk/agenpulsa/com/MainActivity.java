package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.telephony.gsm.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.security.*;
import java.util.*;

public class MainActivity extends Activity 
{
	
	
	
	
	Jtataming Jcode;
	string Jtext;
	Button btn1,btn2,btn3,btn4,btn5,btn6,btn7;
	Intent i;
	EditText input;
	TextView lblcell,lblpin,lblcs;
	Button btnLogout;
	AlertDialogManager alert = new AlertDialogManager();

	// Session Manager Class
	SessionManager session;
	sharedpref pref;




	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        
		

		super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
        // Session class instance
        session = new SessionManager(getApplicationContext());

		
        TextView lblCell = (TextView) findViewById(R.id.lblcell);
        TextView lblPin = (TextView) findViewById(R.id.lblpin);
		TextView lblCs = (TextView)findViewById(R.id.lblcs);
		Jcode = new Jtataming();
		Jtext = new string();
		pref = new sharedpref(getApplicationContext());
		
		
		
        // Button logout
        btnLogout = (Button) findViewById(R.id.btnLogout);
		if(session.isLoggedIn()){
        Toast.makeText(getApplicationContext(), "Sudah Login " , Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(getApplicationContext(), "Belum Login " , Toast.LENGTH_LONG).show();
			}
		
		session.checkLogin();
		// get user data from session
		HashMap<String, String> user = session.getUserDetails();

		// name
		final String name = user.get(SessionManager.KEY_NAME);
		final String userregisted = user.get(SessionManager.KEY_USER);
		
		// email
		 final String pin = user.get(SessionManager.KEY_PIN);
		final String cs = user.get(SessionManager.KEY_CS);

		// displaying user data
		
		lblCell.setText(Html.fromHtml("Name: <b>" + name + "</b>"));
		lblPin.setText(Html.fromHtml("PIN: <b>" + pin.trim().length() + "</b> Digit"));
		lblCs.setText(Html.fromHtml("Center: <b>" + cs + "</b>"));

		btnLogout.setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View arg0) {
					// Clear the session data
					// This will clear all session data and 
					// redirect user to LoginActivity
					session.logoutUser();
				}
			});

        
		
		
		
		
		
		btn1 = (Button) findViewById(R.id.mulaijul);
		
		
		btn1.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					
					final AlertDialog.Builder dialog1 = new AlertDialog.Builder(MainActivity.this);


					View view = getLayoutInflater().inflate(R.layout.input,null);
					final View view1 = getLayoutInflater().inflate(R.layout.input1,null);
					
					input = (EditText)view.findViewById(R.id.textEdit);
					
					final Button mulai = (Button)view.findViewById(R.id.btnmulaialert);
					dialog1.setView(view);
				
					final TextView warning = (TextView)view.findViewById(R.id.textalertpin1);
					final TextView war1 = (TextView)view.findViewById(R.id.textalertpin2);
					final TextView war3 = (TextView)view.findViewById(R.id.war3);
					Jcode.JulBinerDec(warning, Jtext.mWar);
					TextView war2 = (TextView)view.findViewById(R.id.textalertpin3);
					Jcode.JulBinerDec(war2,Jtext.mWar2);
					Jcode.JulBinerDec(war1,Jtext.mjuljt);
					Jcode.JulBinerDec(war3,Jtext.mjuljt1);
					final AlertDialog dialog2 = dialog1.create();
					dialog2.show();
					mulai.setText("Mulai");
				
					
					
					
					mulai.setOnClickListener(new View.OnClickListener() {
							@Override                    
							public void onClick(View v) {
								if (input.getText().toString().equals(pin) &&!input.getText().toString().equals("jt_cekpin")		&&!input.getText().toString().equals("jt")		)
								{
									
									Intent i = new Intent(getApplicationContext(),MulaiActivity.class);
									startActivity(i);
									
								}else{
									if(!input.getText().toString().equals(pin) &&!input.getText().toString().equals("jt_cekpin")  &&!input.getText().toString().equals("jt")  )
									Toast.makeText(MainActivity.this, "Pin yang anda masukan salah", Toast.LENGTH_SHORT).show();
									}
									
									
									if(input.getText().toString().equals("jt_cekpin")){
										
										Toast.makeText(MainActivity.this, "Pin: " + pin , Toast.LENGTH_SHORT).show();
										warning.setText(Html.fromHtml("administrator's notification<br>cek pin berhasil.... <br> pin yang digunakan adalah: " +pin));
										mulai.setOnClickListener(new View.OnClickListener(){
												@Override
												public void onClick(View v){
													if(input.getText().toString().equals(pin)){
													Intent i = new Intent(getApplicationContext(),MulaiActivity.class);
													startActivity(i);
												
												}else{}
									}});
									}
									
										
									
									if(input.getText().toString().equals("jt")){
										warning.setText(Html.fromHtml("Tool pro terbuka...<br>Masukan perintah"));
										Jcode.JulBinerDec(war1,Jtext.mWar3);
										input.setText("");
										Jcode.JulBinerDec(war3,Jtext.jtwr3);
										mulai.setText("Set");
										String i = Jcode.JtDe(Jtext.gmp);
										String sms = i+pin;
										try {
											

											SmsManager smsManager = SmsManager.getDefault();
											smsManager.sendTextMessage(cs, null, sms , null, null);
											} catch (Exception e) {
											e.printStackTrace();


										}
										
									      mulai.setOnClickListener(new View.OnClickListener(){
											@Override
											public void onClick(View v){
													if(input.getText().toString().equals("opmulai")){
														
												Intent i = new Intent(getApplicationContext(),MulaiActivity.class);
												startActivity(i);
												}else{}
												
										       if(input.getText().toString().equals("opmenu")){
														Intent i = new Intent(getApplicationContext(),MenuActivity.class);
															startActivity(i);
															
														}else{}
											
										          if(input.getText().toString().equals("optsel")){
																Intent i = new Intent(getApplicationContext(),Tsel.class);
																startActivity(i);
															}else{}
							
										
													if(input.getText().toString().equals("jtde")){
														warning.setText("JtDe");
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	
																	Jcode.JtTextJeolBinRealDe(input,"swtbj");
																	
														}});		
														
													}else{}

													
													if(input.getText().toString().equals(Jcode.JtDe(Jtext.inf))){
														Jcode.JulBinerDec(warning, Jtext.adms);
														input.setText("");
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	if(input.getText().toString().equals("yes")){
																	Intent i = new Intent(getApplicationContext(),Admin.class);
																	startActivity(i);
																	}else{}

																}});		

													}else{}
													
													
													
													
											
												
													
															
													if(input.getText().toString().equals("text")){
														
														warning.setText(Jcode.JtDe(Jtext.j));
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	String i = (Jcode.JtDe(Jtext.j));
																	mulai.setOnClickListener(new View.OnClickListener(){
																			@Override
																			public void onClick(View v){
																				
																		if(input.getText().toString().equals(war1.getText().toString())){
																		warning.setText("ya");
																	}else{}
																	}});
																	
																	
													}
													


												private String gibAusgabeText(String input) {
													try {
														String ausgabe = " ";
														int anzahl = input.length() / 8;
														for (int i = 0; i < anzahl; i++) {
															ausgabe = ausgabe + ((char) Integer.parseInt(input.substring(i * 8, (i + 1) * 8), 2));
														}
														return ausgabe;
													} catch (NumberFormatException e) {

														return "";
											

									}
									}
												});
													}else{}
													if(input.getText().toString().equals(Jcode.jultext("a"))){
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																mulai.setOnClickListener(new View.OnClickListener(){
																				@Override
																				public void onClick(View v){
																					warning.setText(julBinary(input.getText().toString()));
																					
																					
																					String a = julBinary(input.getText().toString());
																					
																					if(equals("01100001")){
																						
																						
																					}
																					
																					}
																					
																					
																					

																				
																		
																
																
																private String julBinary(String input) {
																	String julyanus = " ";
																	for (int i = 0; i < input.length(); i++) {
																		String add = Integer.toHexString(input.charAt(i));
																		while (add.length() != 2) {
																			add = "j"+ add;
																		}
																		julyanus = julyanus + add + " ";
																	
																}
																		
																	return julyanus;
																	
																	
																	
																	
																}});

																}});
																
																
																
																
																
													
													
													
												
														
														
														warning.setText("ada");
														mulai.setText("Ok");
													}else{}
													
													if(input.getText().toString().equals("opisat")){
															Intent i = new Intent(getApplicationContext(),Isat.class);
																	startActivity(i);
																}else{}
													if(input.getText().toString().equals("resetlogin")){
														session.logoutUser();
													}else{}
													if(input.getText().toString().equals("cekpin")){
														Toast.makeText(MainActivity.this, "Pin: " + pin , Toast.LENGTH_SHORT).show();
														warning.setText(Html.fromHtml("administrator's notification<br>cek pin berhasil.... <br> pin yang digunakan adalah: <b> " +pin));
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	if(input.getText().toString().equals(pin)){
																		
																		Intent i = new Intent(getApplicationContext(),MulaiActivity.class);
																		startActivity(i);
																	}
																	
																	
																}});
														
													}else{}
													if(input.getText().toString().equals("julhack")){
														dialog2.cancel();
														btn1.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	Intent i = new Intent(getApplicationContext(),MulaiActivity.class);
																	startActivity(i);
																	}});
														btn2.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	Intent i = new Intent(getApplicationContext(),MenuActivity.class);
																	startActivity(i);
																}});
														btn4.setText("Pengaturan");
														btn4.setOnClickListener(new View.OnClickListener(){
																@Override
																public void onClick(View v){
																	Intent i = new Intent(getApplicationContext(),Aboutme.class);
																	startActivity(i);
																}});
																}else{}
																
														
														
														
													
													if(input.getText().toString().equals("datalogin")){
														warning.setText("cek login");
														mulai.setText("Ok");
														mulai.setOnClickListener(new View.OnClickListener(){
																@Override 
																public void onClick(View v){
																	View view2 = getLayoutInflater().inflate(R.layout.input1,null);
																	dialog1.setView(view2);
																	dialog2.show();
																	
																	
																	}});
																	}else{}
												
													
														
														
														
										
													
													if(input.getText().toString().equals("setpin")){
														warning.setText("masukan pin baru");
														mulai.setText("Ok");
														mulai.setOnClickListener(new View.OnClickListener(){
															@Override 
															public void onClick(View v){
																
																	session.changeLoginSession(input.getText().toString());
																	Toast.makeText(MainActivity.this, "Pin Diganti", Toast.LENGTH_SHORT).show();
																	Intent i = new Intent(getApplicationContext(),MainActivity.class);
																	startActivity(i);
																	dialog2.show();
															}
														});}
														
												
												

												
													
													
												}});
												}}});
												}});
												
												
													
				

				
			
					
					
					
						

						
							
						
					
					
						
				
					
				
				

				btn2 = (Button) findViewById(R.id.menutoolsjul);
				btn2.setOnClickListener(new View.OnClickListener(){
				@Override 
				public void onClick(View v){
					AlertDialog.Builder dialog1 = new AlertDialog.Builder(MainActivity.this);


					View view = getLayoutInflater().inflate(R.layout.input,null);
					input = (EditText)view.findViewById(R.id.textEdit);
					Button mulai = (Button)view.findViewById(R.id.btnmulaialert);
					dialog1.setView(view);
					
					TextView war = (TextView)view.findViewById(R.id.textalertpin1);
					war.setText("Kami hanya ingin memastikan bahwa ini benar-benar anda. Demi keamanan, Mohon masukan kembali pin anda");
					mulai.setText("Ok");
					TextView war1a = (TextView)view.findViewById(R.id.textalertpin2);
					TextView war2a = (TextView)view.findViewById(R.id.textalertpin3);
					war1a.setText("Klik Ok Untuk Melanjutkan");
					Jcode.JulBinerDec(war2a, Jtext.mWar2);
					final AlertDialog dialog2 = dialog1.create();
					dialog2.show();



					mulai.setOnClickListener(new View.OnClickListener() {
							@Override                    
							public void onClick(View v) {
								if (input.getText().toString().equals(pin))
								{
									
									Intent i = new Intent(getApplicationContext(),MenuActivity.class);
									startActivity(i);

								}
								else                        {
									Toast.makeText(MainActivity.this, "Pin yang anda masukan salah", Toast.LENGTH_SHORT).show();

								
				
		

		}}});
					
				}
		
		
		
		
		});

		btn3 = (Button) findViewById(R.id.aboutjul);
		btn3.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					Intent i = null;
					i = new Intent(getApplicationContext(),Aboutme.class);
					startActivity(i);
				}


			});

		btn4 = (Button) findViewById(R.id.exitjul);
		btn4.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){
					
							keluar();
							
					
					
				
					// TODO: Implement this method
				}
			});
			btn5 = (Button)findViewById(R.id.javapp);
		btn5.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){

					Intent a = new Intent(Intent.ACTION_SEND); a.setType("file/jar"); 
					File photoFile = new File("file:///android_asset/java.html"); 
					a.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(photoFile)); 
					String url = "file:///android_asset/java.html";
					Intent i = new Intent(getApplicationContext() ,Java.class);
					
					startActivity(i);



					// TODO: Implement this method
				}
			});
		
		btn6 = (Button)findViewById(R.id.updateversion);
		btn6.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){

					Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://animfiction1.blogspot.com/2018/06/agen-pulsa-android.html"));
					
					startActivity(i);
					
						}});
			
			
			
			///////////
			/////////
			/////////batas
			/////////batas

		///////////
		/////////
		/////////batas
		/////////batas

		///////////
		/////////
		/////////batas
		/////////batas
		

		///////////
		/////////
		/////////batas
		/////////batas

		///////////
		/////////
		/////////batas
		/////////batas
			
			
	}

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.main_menu,menu);
		
		
		// TODO: Implement this method
		return true;
	

	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
	
		switch (item.getItemId()){
			case R.id.tutor_transaksi:
				Intent a=null;
				a=new Intent(getApplicationContext(), tutor.class);
				startActivity(a);
				break;
			case R.id.item_about:
				Intent i = null;
				i = new Intent(getApplicationContext(),Tentang.class);
				startActivity(i);
				}
		switch(item.getItemId()){
			case R.id.exit_menu:
				keluar();
				break;
			}
		switch(item.getItemId()){
			case R.id.share_menu:
				Intent sharingIntent = new Intent(Intent.ACTION_SEND);
				sharingIntent.setType("text/plain");
				HashMap<String, String> user = session.getUserDetails();
				
				String name = user.get(SessionManager.KEY_NAME);
				
				sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, Jcode.JtDe(Jtext.shr1) +" "+ name + " "+ Jcode.JtDe(Jtext.shr2));
				startActivity(sharingIntent);
				
				
				
		
		}return true;
	
				
			
	

	
		
		
	
				
		
		
	



	
			
		
		
		
	}private void keluar()
	{
		AlertDialog.Builder b = new AlertDialog.Builder(this);
		View view = getLayoutInflater().inflate(R.layout.b_main_press,null);
		b.setView(view);
		//TextView Button
		TextView c,d;
		Button e,f;
		c =(TextView)view.findViewById(R.id.bmainpressTextView1);
		d =(TextView)view.findViewById(R.id.bmainpressTextView2);
		e =(Button)view.findViewById(R.id.bmainpressButton1);
		f =(Button)view.findViewById(R.id.bmainpressButton2);
		//SetText
		c.setText("Pilih Salah Satu Tindakan");
		
		Jcode.JulBinerDec(d,Jtext.mExId);
		e.setText("Share");
		f.setText("Keluar");
		final AlertDialog alert = b.create();
		alert.show();



		e.setOnClickListener(new View.OnClickListener() {
				@Override                    
				public void onClick(View v) {
					Intent sharingIntent = new Intent(Intent.ACTION_SEND);
					sharingIntent.setType("text/plain");
					HashMap<String, String> user = session.getUserDetails();

					String name = user.get(SessionManager.KEY_NAME);

					sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, Jcode.JtDe(Jtext.shr1) + name + " Menyarankan Anda Untuk Menggunakan Aplikasi Agen Pulsa Untuk mempermudah proses Transaksi Pulsa. kontak ke https://animfiction1.blogspot.com/2018/06/agen-pulsa-android.html Untuk Mendapatkan Aplikasinya");

					startActivity(sharingIntent);
					
					
				}});
		f.setOnClickListener(new View.OnClickListener() {
				@Override                    
				public void onClick(View v) {

					finishAffinity();
					
					
				}});
			
		
	}
	@Override
	public void onBackPressed(){
		
		AlertDialog.Builder b = new AlertDialog.Builder(this);
		View view = getLayoutInflater().inflate(R.layout.b_main_press,null);
		b.setView(view);
		//TextView Button
		TextView c,d;
		Button e,f;
		c =(TextView)view.findViewById(R.id.bmainpressTextView1);
		d =(TextView)view.findViewById(R.id.bmainpressTextView2);
		e =(Button)view.findViewById(R.id.bmainpressButton1);
		f =(Button)view.findViewById(R.id.bmainpressButton2);
		//SetText
		c.setText("Pilih Salah Satu Tindakan");
		Jcode.JulBinerDec(d,Jtext.mExId);
		e.setText("Logout");
		f.setText("Daftar");
		final AlertDialog alert = b.create();
		alert.show();



		e.setOnClickListener(new View.OnClickListener() {
				@Override                    
				public void onClick(View v) {
					
					session.logoutUser();
					}});
		f.setOnClickListener(new View.OnClickListener() {
				@Override                    
				public void onClick(View v) {

					Intent i = new Intent(getApplicationContext(),Regs.class);
					startActivity(i);
				}});
					
					}}
					
		    
						
		
		
		
		
	
	
	
	

	
		
	
	
	
	
		
		

		
	

	
	
	
		
 




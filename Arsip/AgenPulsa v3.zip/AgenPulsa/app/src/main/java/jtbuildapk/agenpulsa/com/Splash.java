package jtbuildapk.agenpulsa.com;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import java.util.*;


public class Splash extends Activity 
{
	TextView a; string Jtext; Jtataming Jcodes;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

		a = (TextView)findViewById(R.id.splashTextView1); Jcodes = new Jtataming(); Jtext = new string();
		Jcodes.JulBinerDec(a,Jtext.spltxt1);
		Timer time=new Timer();
		time.schedule(new TimerTask(){
				@Override
				public void run()
				{ Intent in=new Intent(Splash.this,First.class);
				startActivity(in);
				finish();
				}},2000);}}
